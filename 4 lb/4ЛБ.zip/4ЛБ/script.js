const gridContainer = document.getElementById("grid-container");
const restartButton = document.getElementById("restart-btn");
let board = [];
let score = 0;

// Инициализация доски
function init() {
  board = [
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
  ];
  score = 0;
  spawnTile();
  spawnTile();
  updateBoard();
}

// Генерация новой плитки
function spawnTile() {
  const emptyTiles = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (board[r][c] === 0) {
        emptyTiles.push({ r, c });
      }
    }
  }
  const randomTile = emptyTiles[Math.floor(Math.random() * emptyTiles.length)];
  board[randomTile.r][randomTile.c] = Math.random() < 0.9 ? 2 : 4;
}

// Обновление отображения доски
function updateBoard() {
  gridContainer.innerHTML = "";
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      const tile = document.createElement("div");
      tile.className = "tile " + (board[r][c] ? "tile-" + board[r][c] : "");
      tile.innerText = board[r][c] || "";
      gridContainer.appendChild(tile);
    }
  }
}

// Обработка нажатий клавиш
document.addEventListener("keydown", (event) => {
  let moved = false;
  if (event.key === "ArrowUp") moved = slideUp();
  if (event.key === "ArrowDown") moved = slideDown();
  if (event.key === "ArrowLeft") moved = slideLeft();
  if (event.key === "ArrowRight") moved = slideRight();

  if (moved) {
    spawnTile();
    updateBoard();
  }
});

// Движение вверх
function slideUp() {
  let moved = false;
  for (let c = 0; c < 4; c++) {
    let stacked = [0, 0, 0, 0];
    for (let r = 1; r < 4; r++) {
      if (board[r][c] !== 0) {
        let targetRow = r;
        while (
          targetRow > 0 &&
          (board[targetRow - 1][c] === 0 ||
            (board[targetRow - 1][c] === board[r][c] &&
              stacked[targetRow - 1] === 0))
        ) {
          if (board[targetRow - 1][c] === board[r][c]) {
            stacked[targetRow - 1] = 1; // Отметить, что плитка уже объединена
          }
          targetRow--;
        }
        if (targetRow !== r) {
          board[targetRow][c] += board[r][c];
          board[r][c] = 0;
          moved = true;
        }
      }
    }
  }
  return moved;
}

// Движение вниз
function slideDown() {
  let moved = false;
  for (let c = 0; c < 4; c++) {
    let stacked = [0, 0, 0, 0];
    for (let r = 2; r >= 0; r--) {
      if (board[r][c] !== 0) {
        let targetRow = r;
        while (
          targetRow < 3 &&
          (board[targetRow + 1][c] === 0 ||
            (board[targetRow + 1][c] === board[r][c] &&
              stacked[targetRow + 1] === 0))
        ) {
          if (board[targetRow + 1][c] === board[r][c]) {
            stacked[targetRow + 1] = 1; // Отметить, что плитка уже объединена
          }
          targetRow++;
        }
        if (targetRow !== r) {
          board[targetRow][c] += board[r][c];
          board[r][c] = 0;
          moved = true;
        }
      }
    }
  }
  return moved;
}

// Движение влево
function slideLeft() {
  let moved = false;
  for (let r = 0; r < 4; r++) {
    let stacked = [0, 0, 0, 0];
    for (let c = 1; c < 4; c++) {
      if (board[r][c] !== 0) {
        let targetCol = c;
        while (
          targetCol > 0 &&
          (board[r][targetCol - 1] === 0 ||
            (board[r][targetCol - 1] === board[r][c] &&
              stacked[targetCol - 1] === 0))
        ) {
          if (board[r][targetCol - 1] === board[r][c]) {
            stacked[targetCol - 1] = 1; // Отметить, что плитка уже объединена
          }
          targetCol--;
        }
        if (targetCol !== c) {
          board[r][targetCol] += board[r][c];
          board[r][c] = 0;
          moved = true;
        }
      }
    }
  }
  return moved;
}

// Движение вправо
function slideRight() {
  let moved = false;
  for (let r = 0; r < 4; r++) {
    let stacked = [0, 0, 0, 0];
    for (let c = 2; c >= 0; c--) {
      if (board[r][c] !== 0) {
        let targetCol = c;
        while (
          targetCol < 3 &&
          (board[r][targetCol + 1] === 0 ||
            (board[r][targetCol + 1] === board[r][c] &&
              stacked[targetCol + 1] === 0))
        ) {
          if (board[r][targetCol + 1] === board[r][c]) {
            stacked[targetCol + 1] = 1; // Отметить, что плитка уже объединена
          }
          targetCol++;
        }
        if (targetCol !== c) {
          board[r][targetCol] += board[r][c];
          board[r][c] = 0;
          moved = true;
        }
      }
    }
  }
  return moved;
}

// Кнопка перезапуска
restartButton.addEventListener("click", init);

init();
